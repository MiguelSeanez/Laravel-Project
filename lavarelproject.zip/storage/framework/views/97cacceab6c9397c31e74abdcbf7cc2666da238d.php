<li><a href="#" class="nav-link"> <?php echo e(__("Administrar cursos")); ?></a></li>
<li><a href="#" class="nav-link"> <?php echo e(__("Administrar estudiantes")); ?></a></li>
<li><a href="#" class="nav-link"> <?php echo e(__("Administrar profesores")); ?></a></li>
<?php echo $__env->make('partials.navigations.logged', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>