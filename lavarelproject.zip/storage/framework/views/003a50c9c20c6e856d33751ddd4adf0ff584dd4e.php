<div class="col-2">
    <?php if(auth()->guard()->check()): ?>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('opt_for_course', $course)): ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('subscribe', \App\Course::class)): ?>
                <a href="#" class="btn btn-subscribe btn-primary btn-bottom btn-block">
                <i class="fa fa-bolt"></i> <?php echo e(__("Subscribirme")); ?>

                </a>
            <?php else: ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inscribe', $course)): ?>
                    <a href="#" class="btn btn-subscribe btn-primary btn-bottom btn-block">
                    <i class="fa fa-bolt"></i> <?php echo e(__("Inscribirme")); ?>

                    </a>
                <?php else: ?>
                <a href="#" class="btn btn-subscribe btn-primary btn-bottom btn-block">
                <i class="fa fa-bolt"></i> <?php echo e(__("Inscrito")); ?>

                </a>
                <?php endif; ?>
            <?php endif; ?>
        <?php else: ?>   
        <a href="#" class="btn btn-subscribe btn-primary btn-bottom btn-block">
                <i class="fa fa-user"></i> <?php echo e(__("Soy autor")); ?>

                </a>
        <?php endif; ?> 
    <?php else: ?>
    <a href="<?php echo e(route('login')); ?>" class="btn btn-subscribe btn-primary btn-bottom btn-block">
                <i class="fa fa-user"></i> <?php echo e(__("Acceder")); ?>

                </a>
    <?php endif; ?>
</div>