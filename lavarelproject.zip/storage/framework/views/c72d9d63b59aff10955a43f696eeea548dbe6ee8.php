<header>
    <nav class="navbar navbar-expand-md navbar-light navbar-laravel">
        <div class="container">
            <a href="<?php echo e(url('/')); ?>" class="navbar-brand">
                <?php echo e(config('app.name')); ?> 
            </a>

            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarContent" aria-controls="navbarContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
        
            <div class="collapse navbar-collapse" id="navbarContesnt">
                <ul class="navbar-nav mr-auto">
                
                </ul>

                <ul class="navbar-nav ml-auto">

                    <?php echo $__env->make('partials.navigations.' . \App\User::navigation(), array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

                <li class="nav-item dropdown">
                        <a
                            class="nav-link dropdown-toggle"
                            href="#"
                            id="navbarDropdownMenuLink"
                            data-toggle="dropdown"
                            aria-haspopup="true"
                            aria-expanded="false"
                        >
                            <?php echo e(__("Selecciona un idioma")); ?>

                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                            <a
                                class="dropdown-item"
                               href="<?php echo e(route('set_language', ['es'])); ?>"
                            >
                               <?php echo e(__("Español")); ?>

                            </a>
                            <a
                                    class="dropdown-item"
                                    href="<?php echo e(route('set_language', ['en'])); ?>"
                            >
                                <?php echo e(__("Inglés")); ?>

                            </a>
                        </div>
                    </li>
                </ul>
            </div>
        </div>

    </nav>
</header>