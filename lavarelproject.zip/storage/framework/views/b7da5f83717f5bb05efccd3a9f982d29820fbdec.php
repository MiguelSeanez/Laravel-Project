<?php $__env->startSection('jumbotron'); ?>
    <?php echo $__env->make('partials.courses.jumbotron', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="pl-5 pr-5">
        <div class="row justify-content-center">
            <?php echo $__env->make('partials.courses.goals', ['goals' => $course->goals], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials.courses.requirements', ['requirements' => $course->requirements], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->make('partials.courses.description', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>