<div class="row mb-4">
    <div class="col-md-12">
        <div class="card" style="background-image:url('<?php echo e(url('/images/jumbotron.png')); ?>')">
            <div class="text-white text-center d-flex align-items-center py-5 px-4 my-5">
                <div class="col-5">
                    <img src="<?php echo e($course->pathAttachment()); ?>" alt="" class="img-fluid">
                </div>

                <div class="col-5 text-left">
                    <h1><?php echo e(__("Curso")); ?> : <?php echo e($course->name); ?></h1>
                    <h4><?php echo e(__("Profesor")); ?> : <?php echo e($course->teacher->user->name); ?></h4>
                    <h5><?php echo e(__("Categoria")); ?> : <?php echo e($course->category->name); ?></h5>
                    <h5><?php echo e(__("Publicado el")); ?> : <?php echo e($course->created_at->format('d/m/Y')); ?></h5>
                    <h5><?php echo e(__("Actualizado el")); ?> : <?php echo e($course->updated_at->format('d/m/Y')); ?></h5>
                    <h6><?php echo e(__("Estudiantes inscritos")); ?> : <?php echo e($course->students_count); ?></h6>
                    <h6><?php echo e(__("Numero de valoraciones")); ?> : <?php echo e($course->reviews_count); ?></h6>
                    <?php echo $__env->make('partials.courses.rating', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

                <?php echo $__env->make('partials.courses.action_button', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>
</div>