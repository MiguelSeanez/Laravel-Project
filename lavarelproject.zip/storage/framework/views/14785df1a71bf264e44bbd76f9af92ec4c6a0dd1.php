<div class="col-12 pt-0 mt-0">
    <h2 class="text-muted"> <?php echo e(__("Metas del curso")); ?></h2>
    <hr>
</div>

<?php $__empty_1 = true; $__currentLoopData = $goals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $goal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <div class="col-6">
        <card class="bg-light p-3">
            <p class="mb-0">
                <?php echo e($goal->goal); ?>

            </p>
        </card>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="alert alert-black">
        <i class="fa fa-info-circle"></i>
        <?php echo e(__("No se han escrito metas para este curso")); ?>

    </div>
<?php endif; ?>