<li><a href="{{ route('login') }}" class="nav-link"> {{ __("Iniciar Sesión") }}</a></li>
<li><a href="{{ route('register') }}" class="nav-link"> {{ __("Regístrate") }}</a></li>